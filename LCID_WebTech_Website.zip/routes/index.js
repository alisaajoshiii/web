const express = require('express');
const router = express.Router();
const { Product } = require('../models');

router.get('/', async (req, res) => {
  const products = await Product.findAll({ limit: 4 });
  res.render('index', { title: 'Aura Sissies - Home', products });
});

router.get('/contact', (req, res) => {
  res.render('contact', { title: 'Contact Us' });
});

router.post('/contact', (req, res) => {
  // Mock email notification
  console.log('Contact Form Submitted:', req.body);
  res.render('contact', { title: 'Contact Us', message: 'Thank you for contacting us! We will get back to you soon.' });
});

module.exports = router;