// Client side validation can be added here
console.log('Aura Sissies App Loaded');