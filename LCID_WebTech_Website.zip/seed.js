const { sequelize, User, Product } = require('./models');
const bcrypt = require('bcryptjs');

async function seed() {
  await sequelize.sync({ force: true });
  
  // Create admin
  const hashedAdminPassword = await bcrypt.hash('admin123', 10);
  await User.create({
    name: 'Admin User',
    email: 'admin@aurasissies.com',
    password: hashedAdminPassword,
    role: 'admin'
  });

  // Create products based on user input
  await Product.bulkCreate([
    {
      name: 'Rose Bouquet',
      description: 'Beautiful handmade rose bouquet for special occasions.',
      price: 2000,
      category: 'Bouquet',
      image: '1.jpg'
    },
    {
      name: 'Single Rose',
      description: 'A delicate single rose, perfect for a subtle gift.',
      price: 150,
      category: 'Single Flowers',
      image: '2.jpg'
    },
    {
      name: 'Teddybear Keyring',
      description: 'Cute miniature teddy bear customized as a keyring.',
      price: 150,
      category: 'Keyring',
      image: '3.jpg'
    },
    {
      name: 'Keyring Bouquet',
      description: 'Small flowers arranged in a small bouquet as a keyring.',
      price: 200,
      category: 'Keyring',
      image: '4.jpg'
    },
    {
      name: 'Sunflower Keyring',
      description: 'Bright sunflower shaped keyring woven with love.',
      price: 100,
      category: 'Keyring',
      image: '5.jpg'
    }
  ]);

  console.log('Database seeded successfully!');
  process.exit();
}

seed().catch(err => {
  console.error('Seed failed:', err);
  process.exit(1);
});